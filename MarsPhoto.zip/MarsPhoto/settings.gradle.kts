rootProject.name = "MarsPhoto"
