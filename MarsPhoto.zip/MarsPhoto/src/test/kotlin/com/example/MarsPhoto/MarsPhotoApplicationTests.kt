package com.example.MarsPhoto

import org.junit.jupiter.api.Test
import org.springframework.boot.test.context.SpringBootTest

@SpringBootTest
class MarsPhotoApplicationTests {

	@Test
	fun contextLoads() {
	}

}
