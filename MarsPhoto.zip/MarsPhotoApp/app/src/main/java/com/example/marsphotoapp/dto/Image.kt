package com.example.marsphotoapp.dto

data class Image (
    val id: Int = 0,
    val image_url: String = "",
    val des: String = ""
)
